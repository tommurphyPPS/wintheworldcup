GitHub Pages install without replacing your existing home page

Upload the whole 'win-the-origin' folder to your repository root.

Do NOT upload these files into the root next to your existing index.html.
Do NOT replace your current index.html or CNAME.

After upload, the game will be available at:
https://<your-domain>/win-the-origin/

Optional: add a link from your existing home page:
<a href="/win-the-origin/">Play Win The Origin</a>

Files included:
win-the-origin/index.html
win-the-origin/styles.css
win-the-origin/data.js
win-the-origin/app.js
